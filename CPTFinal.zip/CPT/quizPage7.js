function goToNextPage(nextPage) {
  window.location.href = nextPage;
}

function saveAndGoToNextPage(nextPage) {
  if (document.getElementById("name").value) {
    let name = [];
    name[0] = document.getElementById("name").value;
    // Save selected options array as JSON in sessionStorage
    sessionStorage.setItem('NamePageJSON', JSON.stringify(name));
    window.location.href = nextPage;
  } else {
    alert("Please fill the box before proceeding to the next page.");
  }
}