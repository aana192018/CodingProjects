let Page6 = [];

function selectBackground(background) {
  Page6[0] = 'background';
  Page6[1] = background;
  displayOption();
}

function saveAndGoToNextPage(nextPage) {
  if (Page6.length > 0) {
    sessionStorage.setItem('Page6', JSON.stringify(Page6));
    window.location.href = nextPage;
  } else {
    alert("Please select at least one option before proceeding to the next page.");
  }
}

function displayOption() {
  document.getElementById("result").innerHTML = "You have selected " + Page6[1];
}