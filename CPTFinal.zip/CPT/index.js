function goToNextPage(nextPage) {
  window.location.href = nextPage;
  location.replace(nextPage);
}