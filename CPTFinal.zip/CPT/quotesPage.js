let quotes = [];

// saves the values and goes to the next page
function saveQuotesAndNextPage(nextPage) {
  const textInputsFilled =
    document.getElementById("qt1").value.trim() !== "" ||
    document.getElementById("qt2").value.trim() !== "" ||
    document.getElementById("qt3").value.trim() !== "";

  const checkboxesChecked = document.querySelectorAll('input[name="quotes[]"]:checked').length > 0;

  if (textInputsFilled || checkboxesChecked) {
    // Add non-empty text box values to the array
    quotes = [
      document.getElementById("qt1").value.trim(),
      document.getElementById("qt2").value.trim(),
      document.getElementById("qt3").value.trim(),
    ].filter(value => value !== "");

    // Add selected checkboxes to the array
    var selectedCheckboxes = document.querySelectorAll('input[name="quotes[]"]:checked');
    selectedCheckboxes.forEach(function (checkbox) {
      quotes.push(checkbox.value);
    });

    // Save selected options array as JSON in sessionStorage
    sessionStorage.setItem('QuotesPageJSON', JSON.stringify(quotes));
    // Go to the next page
    window.location.href = nextPage;
  } else {
    alert("Please fill in at least one non-empty quote box or check at least one checkbox before proceeding to the next page.");
  }
}