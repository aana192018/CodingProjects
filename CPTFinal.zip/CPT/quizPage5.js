let Page5 = [];

function selectOutfit(outfit) {
  Page5[0] = 'outfit';
  Page5[1] = outfit;
  displayOption();
}

function saveAndGoToNextPage(nextPage) {
  if (Page5.length > 0) {
    sessionStorage.setItem('Page5', JSON.stringify(Page5));
    window.location.href = nextPage;
  } else {
    alert("Please select at least one option before proceeding to the next page.");
  }
}

function displayOption() {
  document.getElementById("result").innerHTML = "You have selected " + Page5[1];
}

function goToNextPage(nextPage) {
  window.location.href = nextPage;
}