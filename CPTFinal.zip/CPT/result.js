function goToNextPage(nextPage) {
  window.location.href = nextPage;
}

function displayElement() {
  let NamePageJSON = sessionStorage.getItem('NamePageJSON');
  let NamePage = NamePageJSON ? JSON.parse(NamePageJSON) : [];
  document.getElementById('name').innerHTML = NamePage[0];
}

function displayQuote() {
  let quotesJSON = sessionStorage.getItem('QuotesPageJSON');
  let quotes = quotesJSON ? JSON.parse(quotesJSON) : [];
  let randomIndex = Math.floor(Math.random() * quotes.length);
  let randomQuote = quotes[randomIndex];
  document.getElementById('quote').innerHTML = randomQuote;
}

function displayImage(pageId, containerId) {
  let pageJSON = sessionStorage.getItem(pageId);
  let page = pageJSON ? JSON.parse(pageJSON) : [];
  let container = document.getElementById(containerId);

  if (container) {
    let imgElement = document.createElement('img');
    imgElement.src = "nobackimages/" + page[1] + ".png";
    imgElement.className = "nobackimages_" + page[1] + "_png";
    container.appendChild(imgElement);
  }
}

// Use a loop to display images for different pages
const pageIds = ['Page1', 'Page2', 'Page3', 'Page4', 'Page5', 'Page6'];
const containerIds = ['accessory', 'skincolor', 'eyes', 'hairstyle', 'outfit', 'background'];

for (let i = 0; i < 7; i++) {
  displayImage(pageIds[i], containerIds[i]);
}

displayImage();
displayElement();
displayQuote();