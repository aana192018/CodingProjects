let Page1 = [];

function selectAccessory(accessory) {
  Page1 = [];
  Page1[0] = 'accessory';
  Page1[1] = accessory;
  displayOption();
}

function saveAndGoToNextPage(nextPage) {
  if (Page1.length > 0) {
    // Save selected options array as JSON in sessionStorage
    sessionStorage.setItem('Page1', JSON.stringify(Page1));
    window.location.href = nextPage;
  } else {
    alert("Please select at least one option before proceeding to the next page.");
  }
}

function displayOption() {
  document.getElementById("result").innerHTML = "You have selected " + Page1[1];
}
// Used https://www.w3schools.com/js/js_json_intro.asp to figure out JSON
// Used https://www.w3schools.com/jsref/prop_win_sessionstorage.asp to figure out how to use sessionStorage