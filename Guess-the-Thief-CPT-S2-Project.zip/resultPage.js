function goToNextPage(nextPage) {
  window.location.href = nextPage;
  location.replace(nextPage);
}

//code created using chatgpt and edited to display the users result, if they won, or if the timer ran out
window.onload = function() {
  //retrieves timer data from page1.js
  let timerData = sessionStorage.getItem('timer');
  //let urlParams = new URLSearchParams(window.location.search);
  // let won = urlParams.get('won');
  if (timerData) {
    let timerResultDisplay = document.getElementById('timerResult');
    timerResultDisplay.innerHTML = JSON.parse(timerData);
    if (JSON.parse(timerData) === "Time's up! You lost, the thief got away!") {
      timerResultDisplay.innerHTML += "<br>Time: 0:00";
    }
    /*else {
      timerResultDisplay.innerHTML += "<br>Time: " + won;
    }*/
  } else {
    let timerResultDisplay = document.getElementById('timerResult');
    timerResultDisplay.innerHTML = "You won!";
  }
}
