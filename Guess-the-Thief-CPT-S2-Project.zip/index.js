//function that goes to the next page, page1.js
function goToNextPage(nextPage) {
  window.location.href = nextPage;
  location.replace(nextPage);
}

//Once you click the instructions button, the function sends an alert that shows the instructions
function instructionalert() {
  alert("Instructions: You were invited to Sir James's 59th birthday party. During the party, the power went out, and the precious $2 million pink diamond went missing. Now, everyone at the party is a suspect, and it's your job to figure out who committed the crime, with what item they used to open the case the diamond is being kept in, and the room the crime was committed in! Help Sir James and catch the thief before the time runs out and the thief escapes! Using the clues provided, make accusations against the rest of the guests, and check off those who are innocent on your checklist. Remember, you only have 10 minutes to figure out who stole the diamond; otherwise, they will get away!");
}