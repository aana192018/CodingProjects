//this function go to the last page resultPage.html
function goToNextPage() {
  window.location.href = "resultPage.html";
}

//this function creates an array called key which stores the answer to who commited the crime, with what weapon, and where
function createkey() {
  let suspects = ["Aubery", "Emma", "Jessica", "Owen", "Micheal"];
  let weapon = ["crowbar", "rope", "hammer", "bat", "screwdriver"];
  let location = ["kitchen", "living room", "bedroom", "office", "basement"];

  //randomly chooses a suspect, weapon, and location and stores it in key
  let key = [];
  key[0] = suspects[Math.floor(Math.random() * suspects.length)];
  key[1] = weapon[Math.floor(Math.random() * weapon.length)];
  key[2] = location[Math.floor(Math.random() * location.length)];

  //takes everything not in key and puts it in a new array called notkey
  let notkey = [];
  let count = 0;
  for (let i = 0; i < 5; i++) {
    if (suspects[i] != key[0]) {
      notkey[count] = suspects[i];
      count++;
    }
  }
  for (let i = 0; i < 5; i++) {
    if (weapon[i] != key[1]) {
      notkey[count] = weapon[i];
      count++;
    }
  }
  for (let i = 0; i < 5; i++) {
    if (location[i] != key[2]) {
      notkey[count] = location[i];
      count++;
    }
  }
  //for testing purposes displays key and not key on the console
  console.log(key);
  console.log(notkey);
  //saves the key, notkey, and weapon arrays to use in the functions below
  sessionStorage.setItem('notkey', JSON.stringify('notkey'));
  sessionStorage.setItem('key', JSON.stringify(key));
  sessionStorage.setItem('weapon', JSON.stringify(weapon));
  // used as a refrence https://www.shecodes.io/athena/11562-how-to-save-an-array-in-local-storage-in-javascript#:~:text=stringify()%20method%20is%20used,name%2Fkey%20for%20that%20array.

}
createkey();

//stores the users input into an array called accusation
function userAccusation() {
  let accusation = [];

  // Gets the selected value from the dropdown
  let selectElement = document.querySelector('select[name="suspects"]');
  let selectedValue = selectElement.options[selectElement.selectedIndex].value;

  let selectElement1 = document.querySelector('select[name="weapon"]');
  let selectedValue1 = selectElement1.options[selectElement1.selectedIndex].value;

  let selectElement2 = document.querySelector('select[name="location"]');
  let selectedValue2 = selectElement2.options[selectElement2.selectedIndex].value;

  // Add the selected value to the accusation array
  accusation[0] = selectedValue;
  accusation[1] = selectedValue1;
  accusation[2] = selectedValue2;
  createPrompts(accusation);
  //everytime the user puts in another input, the array accusation changes to include the new input
}


//prompts created using chatgpt for each character that could be involved in the crime
let promptAubery = "During the investigation, detectives noticed one person's radiant presence at the party, dispelling any suspicion of their involvement in the theft. Their bright outfit stood out in the crowd, making their movements easily traceable. Numerous attendees affirmed their consistent involvement in interactions, laughter, and animated recounting of recent gatherings. Their camaraderie with the guests and evident delight in the festivities served as compelling evidence of their innocence regarding the disappearance of Sir James' precious pink diamond.";
let promptEmma = "As the investigation unfolded, detectives observed one individual whose presence throughout the soirée dispelled any suspicion of their involvement in the theft. Draped in an extravagant dress it was obvious they knew how to dress themselves. The room was filled with the enticing scent of sweets when they walked nearby. The camaraderie they shared with the guests, coupled with their evident delight in the festivities, provided compelling evidence that they were not the culprit behind the disappearance of Sir James' precious pink diamond.";
let promptJessica = "As the investigation unfolded, detectives couldn't help but notice another guest who stood out amidst the revelry. Wrapped in an elegant gown, her poise and elegance were unmistakable. Detectives observed her animated conversations, during which she gracefully gestured, revealing a sizable necklace adorning her neck, a piece she seemed eager to share with others. Her evident fondness for her jewelry reassured the detectives that she could not be the culprit behind the disappearance of Sir James' precious pink diamond.";
let promptOwen = "As the investigation unfolded, detectives discreetly observed another guest. They seem to have a tall frame similar to a hockey player. The peculiar shiny item on their atire caught the eye of many in addendance, seamlessly integrating with their overal appearance. The individual frequently glanced at an object on their hand, occasionally adjusting another nearby item suggesting they were too busy to be the culprit behind the disappearance of Sir James' precious pink diamond.";
let promptMicheal = "As the investigation unfolded detectives observed a guest whose attire stood out amidst the elegance of the event. Amongst the refined ensembles, their choice of clothing was unconventional. They were seen holding a map, adorned with harshly circled areas and labeled spots, suggesting meticulous planning or perhaps a recent exploration. Despite their recent travels abroad and apparent enjoyment of the festivities, they exuded an innocence that suggested they were unlikely to be involved in the disappearance of Sir James' precious pink diamond.";
let promptkitchen = "Detectives searched for clues in this location but all they could find was the lingering aroma of a freshly brewed drink. This was definetly not the place where the crime was commited.";
let promptliving_room = "Detectives searched for clues in this location but all they could find was cushions and ambient lighting creating a cozy ambiance. This was definetly not the place where the crime was commited.";
let promptbedroom = "Detectives searched for clues in this location but all they could find was the scent of lavender and calming oils promoting relaxation and fluffy pillows. This was definetly not the place where the crime was commited.";
let promptoffice = "Detectives searched for clues in this location but all they could find was shelves and cabinetes filled to the brim with items, and a spacious workspace. This was definetly not the place where the crime was commited.";
let promptbasement = "Detectives searched for clues in this location but all they could find were random items in containers, boxes and drawers. The sound of their footsteps echoed on the floors. This was definetly not the place where the crime was commited.";

//this selects a random prompt to be displayed when the user clicks submit after the inputing items in the checkbox array
//this function will be used for the AP test 
//the parameter is the accusation array
function createPrompts(accusation) {
  //displays the accusation array in the console for testing purposes
  console.log(accusation)

  let item = [];
  let count = 0;
  let key_equal_accusation = true;
  //retrives the key array using JSON from the first function 
  let keyJSON = sessionStorage.getItem('key');
  let keyprompt = JSON.parse(keyJSON || "[]");

  //crosschecks the users input/guess with the randomized key, and if the user guesses correctly, it saves the boolean key_equal_accusation as true, if the users input/guess is not matching with the randomized key, then it sets the boolean key_equal_accusation as false
  for (let i = 0; i < 3; i++) {
    if (keyprompt[i] !== accusation[i]) {
      item[count] = accusation[i];
      count++;
      key_equal_accusation = false;
    }
  }
  //if the user guesses correctly, the function will go to the next page, and display that the user won
  if (key_equal_accusation) {
    goToNextPage("resultPage.html");
  }
  //store item into the session storage to use in the function below
  sessionStorage.setItem('item', JSON.stringify(item));
  //calls the function from below
  displayPrompts();
}

//this function randomly chooses from the users incorrect input guesses to display in the prompts as clues
function displayPrompts() {
  //retrieves item from session storage
  let itemJSON = sessionStorage.getItem('item');
  let item = JSON.parse(itemJSON || "[]");

  //randomly chooses from the users incorrect input guesses to display in the prompts as clues
  let randomIndex = "";
  randomIndex = item[Math.floor(Math.random() * item.length)];
  console.log(randomIndex);

  let weaponJSON = sessionStorage.getItem('weapon');
  let weaponprompt = JSON.parse(weaponJSON || "[]");

  //checks if the randomly selected incorrect guess is a weapon, if it is calls the shuffle function, and displays the shuffled weapon on the prompts
  for (let i = 0; i < weaponprompt.length; i++) {
    if (randomIndex == weaponprompt[i]) {
      let wShuffle = randomIndex;
      weaponShuffle = shuffle(wShuffle);
      document.getElementById("hint").innerHTML = "Unshuffle the word to find the weapon that was not used to commit the crime:    "
        + weaponShuffle;
    }
    //chatgpt used to create a more efficent way of retrieving the prompts
    let promptMap = {
      "Aubery": promptAubery,
      "Emma": promptEmma,
      "Jessica": promptJessica,
      "Owen": promptOwen,
      "Micheal": promptMicheal,
      "kitchen": promptkitchen,
      "living room": promptliving_room,
      "bedroom": promptbedroom,
      "office": promptoffice,
      "basement": promptbasement
      //used to display the different prompts when the user plays the games
    };

    //checks if the randomized incorrect guess is in the prompt, if it is it retrieves the specfic prompt for that specfic person or location
    for (let key in promptMap) {
      if (randomIndex === key) {
        randomIndex = promptMap[key];
        let displayElement = document.getElementById('hint');
        displayElement.innerHTML = randomIndex;
        break;
      }
    }
  }

  function shuffle(wShuffle) {
    let array = Array.from(wShuffle);
    for (let i = 0; i < array.length - 1; i++) {
      //line refrenced from https://www.geeksforgeeks.org/word-scramble-game-using-javascript/
      let j = Math.floor(Math.random() * array.length);
      // randomly will swap the letters in the word
      let temp = array[i];
      array[i] = array[j];
      array[j] = temp;
    }
    //checks if the shuffled weapon is correctly shuffled, otherwise runs the function again
    if (array.join("") == wShuffle) {
      shuffle(weaponShuffle);
    }
    return array.join(" ");

  }
}

//code refrenced from https://www.w3schools.com/howto/howto_js_countdown.asp
// 10 minutes from now
window.onload = function() {
  let timerDisplay = document.getElementById('timer');
  let startTime = Date.now();
  let duration = 10 * 60 * 1000; // 10 minutes in milliseconds

  //updates the timer on the screen while the user is playing
  function updateTimer() {
    let elapsed = Date.now() - startTime;
    let remaining = duration - elapsed;
    //checks if the timer has run out, if it has sends the to the next page
    if (remaining <= 0) {
      clearInterval(timerInterval);
      sessionStorage.setItem('timer', JSON.stringify("Time's up! You lost, the thief got away!"));
      goToNextPage();
    }
    else {
      let minutes = Math.floor(remaining / 60000);
      let seconds = Math.floor((remaining % 60000) / 1000);
      timerDisplay.innerHTML = padZero(minutes) + ":" + padZero(seconds);
    }
  }
  timerInterval = setInterval(updateTimer, 1000); // Update timer every second
};

function padZero(num) {
  return (num < 10 ? '0' : '') + num;
}






